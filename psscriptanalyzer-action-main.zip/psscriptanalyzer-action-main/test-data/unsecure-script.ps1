ConvertTo-SecureString "fake" -AsPlainText -Force
