// This file is design to purposfully fail compilation because it should be ignored by the
// 'ignoredTargetPaths' action parameter 

invalid C++